#include <string>
#include <iostream>
#include <filesystem>
#include <string>
using namespace std;

// CMD
// 1 ls: Lists all files and directories in the current path.
// 2 lsd: Lists only directories in the current path.
// 3 lsf: Lists only files in the current path.
// 4 cd_/path: Changes the current directory to the specified path.
// 5 cd..: Moves up one level in the directory hierarchy (goes to the parent directory).

string path = "/Users/olegpona";

// 1
void print_dir()
{
    for(const auto& i : filesystem::directory_iterator(path))
    {
        cout << i.path() << endl;
    }
}

// 2
void print_doc()
{
    for(const auto& i : filesystem::directory_iterator(path))
    {
        if(filesystem::is_directory(i.path()))
        {
            cout << i.path() << endl;
        }

    }
}

// 3
void print_files()
{
    for(const auto& i : filesystem::directory_iterator(path))
    {
        if(filesystem::is_directory(i.path()) == false)
        {
            cout << i.path() << endl;
        }
    }
}

// 4
void cd(string p)
{
    string new_path = p.substr(3, p.length() - 3);
    path += new_path;
}

// 5
void cds()
{
    int lastSlash = path.find_last_of('/');
    path = path.substr(0, lastSlash);
}

int main()
{
    cout << "Welcome to CMD" << endl;

    while (true)
    {

        string p;
        cout << "> ";
        cin >> p;

        if (p == "ls")
        {
            print_dir();
        }
        else if (p == "lsd")
        {
            print_doc();
        }
        else if (p == "lsf")
        {
            print_files();
        }
        else if(p.substr(0, 3) == "cd_")
        {
            cd(p);
        }
        else if(p == "cd..")
        {
            cds();
        }
        else
        {
            cout << "Error!" << endl;
        }
        
    }

    
    return 0;
}
